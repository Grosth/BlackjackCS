import React from 'react';
import GameBoard from './components/GameBoard';

function App() {
  return <GameBoard />;
}

export default App;